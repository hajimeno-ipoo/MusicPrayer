import Accelerate
import AVFoundation
import Foundation

func spectralFrames(_ clip:PCMClip)->[[Double]] {
 let n=4096, half=n/2, bins=174,rate=clip.rate
 let setup=vDSP_create_fftsetup(vDSP_Length(12),FFTRadix(kFFTRadix2))!
 defer{vDSP_destroy_fftsetup(setup)}
 var window=[Float](repeating:0,count:n);vDSP_hann_window(&window,vDSP_Length(n),Int32(vDSP_HANN_NORM))
 var output:[[Double]]=[]
 let channels=Int(clip.buffer.format.channelCount),step=Int(rate*0.2)
 for first in stride(from:Int(rate*1),to:clip.frames-n-Int(rate),by:step) {
  var x=[Float](repeating:0,count:n),re=[Float](repeating:0,count:half),im=[Float](repeating:0,count:half),power=[Float](repeating:0,count:half)
  for c in 0..<channels {let p=clip.buffer.floatChannelData![c];for j in 0..<n{x[j] += p[first+j]/Float(channels)}}
  vDSP_vmul(x,1,window,1,&x,1,vDSP_Length(n))
  re.withUnsafeMutableBufferPointer{r in im.withUnsafeMutableBufferPointer{q in
   var split=DSPSplitComplex(realp:r.baseAddress!,imagp:q.baseAddress!)
   x.withUnsafeBufferPointer{v in v.baseAddress!.withMemoryRebound(to:DSPComplex.self,capacity:half){vDSP_ctoz($0,2,&split,1,vDSP_Length(half))}}
   vDSP_fft_zrip(setup,&split,1,vDSP_Length(12),FFTDirection(FFT_FORWARD))
   vDSP_zvmags(&split,1,&power,1,vDSP_Length(half))
  }}
  var row:[Double]=[]
  for b in 0..<bins {
   let f=80*pow(2,Double(b)/24),lo=max(1,Int(f*pow(2,-1/48.0)*Double(n)/rate)),hi=min(half-1,max(lo+1,Int(f*pow(2,1/48.0)*Double(n)/rate)))
   let value=(lo...hi).reduce(0.0){$0+Double(power[$1])}/Double(hi-lo+1)
   row.append(log(max(1e-16,value)))
  }
  output.append(row)
 }
 return output
}
