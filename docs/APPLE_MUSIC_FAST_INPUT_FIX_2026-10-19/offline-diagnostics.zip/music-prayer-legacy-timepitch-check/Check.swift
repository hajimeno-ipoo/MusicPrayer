import AVFoundation
import Foundation
@main struct Check {
 static func main() throws {
  let rate=48000.0,n=Int(rate*3),fmt=AVAudioFormat(standardFormatWithSampleRate:rate,channels:1)!
  var result:[String:Any]=[:]
  for kind in ["bass110","percussive"] {
   let input=AVAudioPCMBuffer(pcmFormat:fmt,frameCapacity:AVAudioFrameCount(n))!;input.frameLength=input.frameCapacity
   let p=input.floatChannelData![0]
   var rng:UInt64=9271
   for i in 0..<n {
    let t=Double(i)/rate
    rng = rng &* 6364136223846793005 &+ 1442695040888963407
    let noise=Double(Int64(bitPattern:rng)>>11)/Double(Int64.max>>11)
    let since=t.truncatingRemainder(dividingBy:0.5)-0.25
    let burst=(since>=0 && since<0.2) ? since : -1
    let noiseEnv=burst>=0 ? exp(-burst/0.025):0
    switch kind {
    case "tone440":p[i]=Float(0.25*sin(2 * .pi * 440*t))
    case "bass110":p[i]=Float(0.25*sin(2 * .pi * 110*t))
    case "noiseBursts":p[i]=Float(0.6*noise*noiseEnv)
    default:p[i]=Float(burst>=0 ? (0.45*sin(2 * .pi * 65*burst)*exp(-burst/0.07)+0.3*noise*noiseEnv):0)
    }
   }
   let base=metrics(input,sourceDuration:3)
   var variants:[String:Any]=["input":base]
   for overlap:Float in [8] {
    let began=Date(),(output,d)=try LegacyTimeExpansion.render(input,smoothness:overlap)
    let m=metrics(output,sourceDuration:6)
    if kind == "bass110" {let p=output.floatChannelData![0];var crossings=0;for i in 48001..<192000{if p[i-1] <= 0 && p[i]>0 {crossings += 1}};print("frequencyHz",Double(crossings)/3)}
    variants[String(Int(overlap))]=["metrics":m,"diagnostics":d,"seconds":Date().timeIntervalSince(began),"RMSGainDB":20*log10((m["rms"] as! Double)/(base["rms"] as! Double)),"peakGainDB":20*log10((m["peak"] as! Double)/(base["peak"] as! Double))]
   }
   result[kind]=variants
  }
  let data=try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys])
  try data.write(to:URL(fileURLWithPath:"/private/tmp/music-prayer-legacy-timepitch-check/results.json"))
  print(String(data:data,encoding:.utf8)!)
 }
 static func metrics(_ buffer:AVAudioPCMBuffer,sourceDuration:Double)->[String:Any] {
  let p=buffer.floatChannelData![0],rate=buffer.format.sampleRate,n=Int(buffer.frameLength)
  let ratio=sourceDuration/3
  let first=Int(rate*0.1*ratio),last=n-Int(rate*0.1*ratio)
  var peak=0.0,sum=0.0
  for i in first..<last {let v=Double(p[i]);peak=max(peak,abs(v));sum += v*v}
  var windows:[[String:Double]]=[]
  for onset in [0.25,0.75,1.25,1.75,2.25,2.75] {
   let expected=onset*ratio,lo=Int((expected-0.05)*rate),hi=min(n,Int((expected+0.15)*rate))
   let block=240
   var maxRMS=0.0,selected=lo
   for i in stride(from:lo,to:hi-block,by:block) {
    var power=0.0;for j in i..<(i+block){power += Double(p[j])*Double(p[j])}
    let rms=sqrt(power/Double(block));if rms>maxRMS{maxRMS=rms;selected=i}
   }
   windows.append(["expected":expected,"peak5msRMS":maxRMS,"peakTime":Double(selected)/rate,"peakOffsetSeconds":Double(selected)/rate-expected])
  }
  return ["frames":n,"rms":sqrt(sum/Double(last-first)),"peak":peak,"transients":windows]
 }
}
