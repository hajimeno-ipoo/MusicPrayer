#!/usr/bin/env python3
"""Compare aligned MusicAnalysis JSON results. Python standard library only.

Run after the probe completes:
  python3 /private/tmp/music-prayer-controlled/compare.py
The 50 ms event window is descriptive; it is not a quality acceptance threshold.
"""

import argparse
import bisect
import json
import math
from pathlib import Path
import statistics


NAMES = (
    "reference_a", "reference_b", "reference_c", "reference_half_rate",
    "pitch_kept_2x", "pitch_shifted_half_rate", "pitch_shifted_resampled_native",
)
EVENT_WINDOW = 0.050
GRID_STEP = 0.100


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def percentile(values, fraction):
    if not values:
        return None
    values = sorted(values)
    at = (len(values) - 1) * fraction
    lo, hi = math.floor(at), math.ceil(at)
    return values[lo] + (values[hi] - values[lo]) * (at - lo)


def distribution(values):
    values = [float(x) for x in values if finite(x)]
    return {
        "count": len(values),
        "median": statistics.median(values) if values else None,
        "p95": percentile(values, 0.95),
        "max": max(values) if values else None,
    }


def point_times(values):
    return sorted(float(x) for x in values if finite(x))


def nearest_differences(source, target):
    if not target:
        return []
    distances = []
    for x in source:
        i = bisect.bisect_left(target, x)
        neighbors = target[max(0, i - 1):min(len(target), i + 1)]
        distances.append(min(abs(x - y) for y in neighbors))
    return distances


def compare_events(reference, candidate, window=EVENT_WINDOW):
    a, b = point_times(reference), point_times(candidate)
    i = j = 0
    paired, missing_a, missing_b = [], [], []
    while i < len(a) and j < len(b):
        delta = b[j] - a[i]
        if abs(delta) <= window + 1e-12:
            paired.append(delta)
            i += 1
            j += 1
        elif a[i] < b[j]:
            missing_a.append(a[i])
            i += 1
        else:
            missing_b.append(b[j])
            j += 1
    missing_a.extend(a[i:])
    missing_b.extend(b[j:])
    return {
        "referenceCount": len(a), "candidateCount": len(b),
        "nearestAbsSecondsReferenceToCandidate": distribution(nearest_differences(a, b)),
        "nearestAbsSecondsCandidateToReference": distribution(nearest_differences(b, a)),
        "oneToOneWindowSeconds": window,
        "oneToOneMatched": len(paired),
        "oneToOneUnmatchedReference": len(missing_a),
        "oneToOneUnmatchedCandidate": len(missing_b),
        "unmatchedReferenceTimes": missing_a,
        "unmatchedCandidateTimes": missing_b,
        "matchedAbsSeconds": distribution([abs(x) for x in paired]),
        "matchedSignedMedianSeconds": statistics.median(paired) if paired else None,
    }


def spans(values, nested=False):
    result = []
    for value in values:
        span = value.get("range", {}) if nested else value
        start, duration = span.get("start"), span.get("duration")
        if finite(start) and finite(duration) and duration > 0:
            result.append((float(start), float(start + duration), value))
    return sorted(result, key=lambda x: (x[0], x[1]))


def union_ranges(ranges, end):
    merged = []
    for start, stop, _ in ranges:
        start, stop = max(0.0, start), min(end, stop)
        if stop <= start:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], stop)
        else:
            merged.append([start, stop])
    return merged


def overlap_seconds(a, b):
    i = j = 0
    total = 0.0
    while i < len(a) and j < len(b):
        total += max(0.0, min(a[i][1], b[j][1]) - max(a[i][0], b[j][0]))
        if a[i][1] < b[j][1]:
            i += 1
        else:
            j += 1
    return total


def compare_ranges(reference, candidate, end, nested=False):
    a, b = spans(reference, nested), spans(candidate, nested)
    ua, ub = union_ranges(a, end), union_ranges(b, end)
    da, db = sum(y - x for x, y in ua), sum(y - x for x, y in ub)
    intersection = overlap_seconds(ua, ub)
    union = da + db - intersection
    return {
        "referenceCount": len(a), "candidateCount": len(b),
        "startBoundaries": compare_events([x[0] for x in a], [x[0] for x in b]),
        "endBoundaries": compare_events([x[1] for x in a], [x[1] for x in b]),
        "referenceCoveredSeconds": da, "candidateCoveredSeconds": db,
        "intersectionSeconds": intersection,
        "unionSeconds": union,
        "coverageIoU": intersection / union if union else None,
        "symmetricDifferenceSeconds": max(0.0, da + db - 2 * intersection),
    }


def numeric_pairs(pairs):
    if not pairs:
        return {"compared": 0, "mae": None, "rmse": None, "biasCandidateMinusReference": None,
                "maxAbsDifference": None, "pearson": None}
    a, b = zip(*pairs)
    diff = [y - x for x, y in pairs]
    ma, mb = statistics.fmean(a), statistics.fmean(b)
    va = sum((x - ma) ** 2 for x in a)
    vb = sum((y - mb) ** 2 for y in b)
    corr = sum((x - ma) * (y - mb) for x, y in pairs) / math.sqrt(va * vb) if va > 0 and vb > 0 else None
    return {
        "compared": len(pairs), "mae": statistics.fmean(abs(x) for x in diff),
        "rmse": math.sqrt(statistics.fmean(x * x for x in diff)),
        "biasCandidateMinusReference": statistics.fmean(diff),
        "maxAbsDifference": max(abs(x) for x in diff),
        "absDifferenceP95": percentile([abs(x) for x in diff], 0.95),
        "pearson": corr,
    }


def grid(end):
    return [i * GRID_STEP for i in range(max(0, math.ceil(end / GRID_STEP))) if i * GRID_STEP < end]


def series(values):
    # A duplicate timestamp's last entry is used, and duplicates are reported.
    result = {}
    usable = 0
    for value in values:
        if finite(value.get("time")) and finite(value.get("value")):
            usable += 1
            result[float(value["time"])] = float(value["value"])
    ordered = sorted(result.items())
    return [x for x, _ in ordered], [y for _, y in ordered], usable - len(ordered)


def interpolated(times, values, t):
    if not times or t < times[0] or t > times[-1]:
        return None
    i = bisect.bisect_left(times, t)
    if i < len(times) and times[i] == t:
        return values[i]
    if i == 0 or i == len(times):
        return None
    fraction = (t - times[i - 1]) / (times[i] - times[i - 1])
    return values[i - 1] + fraction * (values[i] - values[i - 1])


def compare_series(reference, candidate, ticks):
    at, av, ad = series(reference)
    bt, bv, bd = series(candidate)
    pairs = []
    reference_present = candidate_present = 0
    for t in ticks:
        x, y = interpolated(at, av, t), interpolated(bt, bv, t)
        reference_present += x is not None
        candidate_present += y is not None
        if x is not None and y is not None:
            pairs.append((x, y))
    return {
        "referenceCount": len(reference), "candidateCount": len(candidate),
        "referenceDuplicateTimes": ad, "candidateDuplicateTimes": bd,
        "gridStepSeconds": GRID_STEP, "gridCount": len(ticks),
        "referencePresentGridCount": reference_present,
        "candidatePresentGridCount": candidate_present,
        "interpolation": "linear within reported sample support; no extrapolation",
        **numeric_pairs(pairs),
    }


def compare_step_values(reference, candidate, ticks, categorical=False):
    a, b = spans(reference, True), spans(candidate, True)
    pairs = []
    reference_present = candidate_present = only_a = only_b = both_absent = ambiguous_a = ambiguous_b = 0
    agreements = 0
    for t in ticks:
        ar = [x[2] for x in a if x[0] <= t < x[1]]
        br = [x[2] for x in b if x[0] <= t < x[1]]
        ambiguous_a += len(ar) > 1
        ambiguous_b += len(br) > 1
        reference_present += bool(ar)
        candidate_present += bool(br)
        only_a += bool(ar) and not br
        only_b += bool(br) and not ar
        both_absent += not ar and not br
        if len(ar) == 1 and len(br) == 1:
            if categorical:
                pairs.append((ar[0].get("label"), br[0].get("label")))
                agreements += (ar[0].get("label"), ar[0].get("minor")) == (br[0].get("label"), br[0].get("minor"))
            elif finite(ar[0].get("value")) and finite(br[0].get("value")):
                pairs.append((float(ar[0]["value"]), float(br[0]["value"])))
    result = {
        "gridStepSeconds": GRID_STEP, "gridCount": len(ticks),
        "referencePresentGridCount": reference_present,
        "candidatePresentGridCount": candidate_present,
        "onlyReferenceGridCount": only_a, "onlyCandidateGridCount": only_b,
        "bothAbsentGridCount": both_absent,
        "referenceAmbiguousOverlapGridCount": ambiguous_a,
        "candidateAmbiguousOverlapGridCount": ambiguous_b,
        "intervalMembership": "half-open [start,end); overlapping intervals excluded from value comparison",
    }
    if categorical:
        result.update({"compared": len(pairs), "agreeingGridCount": agreements,
                       "agreementFractionAmongComparable": agreements / len(pairs) if pairs else None,
                       "referenceLabels": sorted({str(x[0]) for x in pairs}),
                       "candidateLabels": sorted({str(x[1]) for x in pairs})})
    else:
        result.update(numeric_pairs(pairs))
    return result


def without_fingerprint(value):
    return {k: v for k, v in value.items() if k != "fingerprint"}


def scalar_difference(a, b):
    return {"reference": a, "candidate": b, "candidateMinusReference": b - a if finite(a) and finite(b) else None}


def compare_analysis(reference, candidate):
    end = min(reference["duration"], candidate["duration"])
    ticks = grid(end)
    a, b = without_fingerprint(reference), without_fingerprint(candidate)
    result = {
        "exactlyEqualExcludingFingerprint": a == b,
        "differentTopLevelFields": [key for key in sorted(set(a) | set(b)) if a.get(key) != b.get(key)],
        "commonRangeSeconds": [0.0, end],
        "duration": scalar_difference(reference.get("duration"), candidate.get("duration")),
        "bpm": scalar_difference(reference.get("bpm"), candidate.get("bpm")),
        "integrated": scalar_difference(reference.get("integrated"), candidate.get("integrated")),
        "beats": compare_events(reference.get("beats", []), candidate.get("beats", [])),
        "bars": compare_events(reference.get("bars", []), candidate.get("bars", [])),
        "ranges": {}, "activityAndLoudness": {},
    }
    for name in ("sections", "segments", "phrases", "pace", "keys"):
        result["ranges"][name] = compare_ranges(reference.get(name, []), candidate.get(name, []), end, nested=name in ("pace", "keys"))
    for name in ("vocal", "drums", "bass", "other"):
        result["ranges"]["instrumentRanges." + name] = compare_ranges(
            reference.get("instrumentRanges", {}).get(name, []), candidate.get("instrumentRanges", {}).get(name, []), end)
    result["paceValues"] = compare_step_values(reference.get("pace", []), candidate.get("pace", []), ticks)
    result["keyValues"] = compare_step_values(reference.get("keys", []), candidate.get("keys", []), ticks, True)
    for name in ("vocal", "drums", "bass", "other", "momentary", "shortTerm"):
        result["activityAndLoudness"][name] = compare_series(reference.get(name, []), candidate.get(name, []), ticks)
    ap, bp = reference.get("peak"), candidate.get("peak")
    result["peak"] = {
        "time": scalar_difference(ap.get("time") if ap else None, bp.get("time") if bp else None),
        "value": scalar_difference(ap.get("value") if ap else None, bp.get("value") if bp else None),
    }
    return result


def read_events(root):
    path = root / "events.jsonl"
    if not path.exists():
        return [], []
    starts, ends = [], []
    for line in path.read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue  # A final line may still be in the process of being written.
        if row.get("event") == "analysisStart":
            starts.append(row)
        elif row.get("event") == "analysisResult":
            ends.append(row)
    return starts, ends


def main(root, allow_partial=False):
    missing = [name for name in NAMES if not (root / (name + ".json")).exists()]
    if missing and not allow_partial:
        raise SystemExit("Waiting for analysis JSON files: " + ", ".join(missing))
    if "reference_a" in missing:
        raise SystemExit("reference_a.json is required")
    data = {name: json.loads((root / (name + ".json")).read_text()) for name in NAMES if name not in missing}
    starts, ends = read_events(root)
    starts_by_name = {row["name"]: row for row in starts}
    ends_by_name = {row["name"]: row for row in ends}
    feed_checks = {}
    for name, start in starts_by_name.items():
        end = ends_by_name.get(name)
        feed_checks[name] = {
            "start": start, "result": end,
            "allFramesAndChunksConsumed": (end.get("fedFrames") == start.get("frames") and end.get("fedChunks") == start.get("chunks")) if end else None,
        }
    baseline_starts = [starts_by_name.get(name) for name in ("reference_a", "reference_b", "reference_c")]
    keys = ("frames", "rate", "duration", "chunks", "sha256", "timeScale")
    same_inputs = all(baseline_starts) and all(
        all(row.get(key) == baseline_starts[0].get(key) for key in keys) for row in baseline_starts[1:])
    output = {
        "method": {
            "reference": "reference_a", "missingFiles": missing,
            "eventWindowSeconds": EVENT_WINDOW,
            "eventWindowIsAcceptanceCriterion": False,
            "oneToOneMethod": "maximum-count ordered matching within a fixed time window; signed delta=candidate-reference",
            "nearestDifferenceMethod": "bidirectional nearest absolute differences; not a one-to-one match",
            "gridStepSeconds": GRID_STEP,
            "gridRange": "0 inclusive to min(reference.duration,candidate.duration) exclusive; input already time-normalized by probe",
            "timeAlignmentAddedByScript": False,
            "limitations": [
                "An identical reference tests reproducibility of this input, not musical ground truth.",
                "50 ms matching and 100 ms grids are descriptive measurement choices, not pass/fail criteria.",
                "Boundary nearest-neighbor matches do not establish semantic correspondence of intervals.",
                "100 ms grids can miss shorter mismatches; full source JSON is retained for inspection.",
                "The script uses probe alignment and time normalization; it does not repair input offsets.",
                "No acceptance thresholds or causal attribution are inferred from these metrics.",
            ],
        },
        "baselineInputMetadataIdentical": bool(same_inputs),
        "feedChecks": feed_checks,
        "comparisons": {name: compare_analysis(data["reference_a"], value) for name, value in data.items() if name != "reference_a"},
    }
    path = root / "comparison.json"
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"output": str(path), "compared": list(output["comparisons"]),
                      "baselineExactExcludingFingerprint": {name: output["comparisons"].get(name, {}).get("exactlyEqualExcludingFingerprint") for name in ("reference_b", "reference_c")}}, ensure_ascii=False))


def self_test():
    assert distribution([])["median"] is None
    assert distribution([0, 0.1, 0.2])["median"] == 0.1
    matched = compare_events([1, 2, 3], [1.02, 2.08, 3.01])
    assert matched["oneToOneMatched"] == 2
    assert matched["oneToOneUnmatchedReference"] == 1
    assert matched["oneToOneUnmatchedCandidate"] == 1
    assert compare_events([], [1])["oneToOneUnmatchedCandidate"] == 1
    assert compare_events([1], [])["nearestAbsSecondsReferenceToCandidate"]["count"] == 0
    ranges = compare_ranges([{"start": 0, "duration": 1}], [{"start": 0.5, "duration": 1}], 2)
    assert math.isclose(ranges["coverageIoU"], 1 / 3)
    compared = compare_series([{"time": 0, "value": 0}, {"time": 1, "value": 1}],
                              [{"time": 0, "value": 1}, {"time": 1, "value": 2}], [0, 0.5, 1])
    assert compared["compared"] == 3 and compared["mae"] == 1
    base = {"duration": 1, "fingerprint": "a", "beats": [0.2, 0.7], "pace": [{"range": {"start": 0, "duration": 1}, "value": 0.5}]}
    other = dict(base, fingerprint="b")
    result = compare_analysis(base, other)
    assert result["exactlyEqualExcludingFingerprint"]
    assert result["paceValues"]["mae"] == 0
    assert result["beats"]["oneToOneMatched"] == 2
    print("self-test passed (in-memory synthetic data; no audio experiments)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--allow-partial", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    else:
        main(args.directory, args.allow_partial)
