import AVFoundation
import Foundation
// Only the RAM collector depends on the product input copier; this utility check never captures audio.
enum AppleMusicAnalysisInput {static func copy(_ list:UnsafePointer<AudioBufferList>,sampleRate:Double,gain:Float)->AVAudioPCMBuffer?{nil}}
@main struct Check {
 static func main() throws {
  let b=PCMClip.allocate(48000,2,144000)
  for c in 0..<2 {for i in 0..<144000 {b.floatChannelData![c][i]=Float(sin(2 * Double.pi * 440 * Double(i)/48000))}}
  let original=PCMClip(buffer:b), converted=try original.resample(24000), relabeled=original.relabel(24000)
  func frequency(_ clip:PCMClip)->Double {
   let a=Int(clip.rate*0.1),z=clip.frames-a,p=clip.buffer.floatChannelData![0];var crossings=0
   for i in (a+1)..<z {if p[i-1]<=0 && p[i]>0 {crossings += 1}}
   return Double(crossings)/(Double(z-a)/clip.rate)
  }
  var ref:[Double]=[],seed:UInt64=7
  for _ in 0..<21000 {seed=seed &* 6364136223846793005 &+ 1;ref.append(Double(seed>>32)/Double(UInt32.max))}
  let candidate=Array(repeating:0.0,count:143)+ref
  let result=align(ref,candidate)
  let ok=abs(converted.duration-3)<0.001 && abs(frequency(converted)-440)<1 && abs(relabeled.duration-6)<0.001 && abs(frequency(relabeled)-220)<1 && abs((result["offsetSeconds"] as! Double)-1.43)<0.001
  let output:[String:Any] = ["passed":ok,"convertedFrames":converted.frames,"convertedSeconds":converted.duration,"convertedHz":frequency(converted),"relabelSeconds":relabeled.duration,"relabelHz":frequency(relabeled),"alignment":result]
  print(String(data:try JSONSerialization.data(withJSONObject:output,options:[.sortedKeys]),encoding:.utf8)!)
  if !ok {throw NSError(domain:"UtilityCheck.failed",code:1)}
 }
}
