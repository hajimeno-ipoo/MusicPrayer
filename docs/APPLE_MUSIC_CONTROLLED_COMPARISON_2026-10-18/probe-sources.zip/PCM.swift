import AVFoundation
import CryptoKit
import Foundation

final class RAMCollector: @unchecked Sendable {
    private let lock=NSLock()
    private var enabled=false, valid=true
    private var buffers:[AVAudioPCMBuffer]=[]
    private var frames=0
    private var lastHost:UInt64=0
    private var lastSeconds:Double=0
    private var maxGap:Double=0
    func begin() {lock.lock();defer{lock.unlock()};buffers=[];frames=0;valid=true;lastHost=0;lastSeconds=0;maxGap=0;enabled=true}
    func append(_ list: UnsafePointer<AudioBufferList>, rate:Double, host:UInt64) {
        lock.lock();defer{lock.unlock()};guard enabled else{return}
        guard frames < Int(rate*300), let b=AppleMusicAnalysisInput.copy(list,sampleRate:rate,gain:Float(1/0.12)) else {valid=false;return}
        if lastHost>0,host>lastHost {maxGap=max(maxGap,AVAudioTime.seconds(forHostTime:host-lastHost)-lastSeconds)}
        lastHost=host;lastSeconds=Double(b.frameLength)/rate
        frames += Int(b.frameLength);buffers.append(b)
    }
    func end() throws -> (PCMClip,[String:Any]) {
        lock.lock();enabled=false;let values=buffers;let ok=valid;let gap=maxGap;buffers=[];lock.unlock()
        guard ok,!values.isEmpty else{throw NSError(domain:"Probe.invalidRAMCapture",code:1)}
        return (try PCMClip.join(values),["buffers":values.count,"valid":ok,"maxCallbackGapSeconds":gap])
    }
}
struct PCMClip {
    let buffer:AVAudioPCMBuffer
    var rate:Double {buffer.format.sampleRate}
    var frames:Int {Int(buffer.frameLength)}
    var duration:Double {Double(frames)/rate}
    static func allocate(_ rate:Double,_ channels:AVAudioChannelCount,_ frames:Int)->AVAudioPCMBuffer {
        let b=AVAudioPCMBuffer(pcmFormat:AVAudioFormat(standardFormatWithSampleRate:rate,channels:channels)!,frameCapacity:AVAudioFrameCount(frames))!
        b.frameLength=AVAudioFrameCount(frames);return b
    }
    static func join(_ values:[AVAudioPCMBuffer]) throws -> PCMClip {
        guard let first=values.first else{throw NSError(domain:"Probe.emptyPCM",code:1)}
        let total=values.reduce(0){$0+Int($1.frameLength)}, output=allocate(first.format.sampleRate,first.format.channelCount,total)
        var position=0
        for b in values {
            guard b.format==first.format else{throw NSError(domain:"Probe.formatChanged",code:1)}
            for c in 0..<Int(b.format.channelCount) {memcpy(output.floatChannelData![c]+position,b.floatChannelData![c],Int(b.frameLength)*4)}
            position += Int(b.frameLength)
        }
        return PCMClip(buffer:output)
    }
    func slice(start:Double,duration:Double)->PCMClip {
        let a=max(0,Int((start*rate).rounded())), n=min(frames-a,Int((duration*rate).rounded()))
        precondition(n>0 && a+n<=frames)
        let b=Self.allocate(rate,buffer.format.channelCount,n)
        for c in 0..<Int(buffer.format.channelCount) {memcpy(b.floatChannelData![c],buffer.floatChannelData![c]+a,n*4)}
        return PCMClip(buffer:b)
    }
    func relabel(_ newRate:Double)->PCMClip {
        let b=Self.allocate(newRate,buffer.format.channelCount,frames)
        for c in 0..<Int(buffer.format.channelCount) {memcpy(b.floatChannelData![c],buffer.floatChannelData![c],frames*4)}
        return PCMClip(buffer:b)
    }
    func resample(_ newRate:Double) throws -> PCMClip {
        let format=AVAudioFormat(standardFormatWithSampleRate:newRate,channels:buffer.format.channelCount)!
        guard let converter=AVAudioConverter(from:buffer.format,to:format) else{throw NSError(domain:"Probe.converter",code:1)}
        converter.sampleRateConverterQuality=AVAudioQuality.max.rawValue
        var cursor=0, outputs:[AVAudioPCMBuffer]=[]
        for _ in 0..<10000 {
            let out=Self.allocate(newRate,buffer.format.channelCount,16384)
            out.frameLength=0
            var err:NSError?
            let status=converter.convert(to:out,error:&err) { requested,state in
                guard cursor<frames else{state.pointee = .endOfStream;return nil}
                let n=min(Int(requested),frames-cursor), b=Self.allocate(rate,buffer.format.channelCount,n)
                for c in 0..<Int(buffer.format.channelCount) {memcpy(b.floatChannelData![c],buffer.floatChannelData![c]+cursor,n*4)}
                cursor += n;state.pointee = .haveData;return b
            }
            if let err {throw err}
            if out.frameLength>0 {outputs.append(out)}
            if status == .endOfStream {return try Self.join(outputs)}
            if status == .error {throw NSError(domain:"Probe.converterError",code:1)}
        }
        throw NSError(domain:"Probe.converterTimeout",code:1)
    }
    func envelope(originalTimeScale:Double)->[Double] {
        let window=max(1,Int(rate*0.01/originalTimeScale)), channels=Int(buffer.format.channelCount)
        var result:[Double]=[]
        for first in stride(from:0,to:frames-window,by:window) {
            var sum:Double=0
            for c in 0..<channels {
                let p=buffer.floatChannelData![c]
                for i in first..<(first+window) {sum += Double(p[i]*p[i])}
            }
            result.append(sqrt(sum/Double(window*channels)))
        }
        return result
    }
    func fingerprint()->String {
        var h=SHA256()
        for c in 0..<Int(buffer.format.channelCount) {h.update(data:Data(bytes:buffer.floatChannelData![c],count:frames*4))}
        return h.finalize().map{String(format:"%02x",$0)}.joined()
    }
    func chunks()->[AVReadOnlyAudioPCMBuffer] {
        var values:[AVReadOnlyAudioPCMBuffer]=[]
        for i in stride(from:0,to:frames,by:4096) {
            let n=min(4096,frames-i), b=Self.allocate(rate,buffer.format.channelCount,n)
            for c in 0..<Int(buffer.format.channelCount) {memcpy(b.floatChannelData![c],buffer.floatChannelData![c]+i,n*4)}
            values.append(AVReadOnlyAudioPCMBuffer(copying:b))
        }
        return values
    }
}
struct PCMSequence:AsyncSequence,Sendable {
    typealias Element=AVReadOnlyAudioPCMBuffer
    let values:[Element]
    let counter:FeedCounter
    struct AsyncIterator:AsyncIteratorProtocol {
        let values:[Element];let counter:FeedCounter;var index=0
        mutating func next() async -> Element? {
            guard index<values.count else{return nil};defer{index += 1}
            let b=values[index];counter.add(b.frameLength);return b
        }
    }
    func makeAsyncIterator()->AsyncIterator {AsyncIterator(values:values,counter:counter)}
}
final class FeedCounter:@unchecked Sendable {
    private let lock=NSLock();private var frames=0;private var chunks=0
    func add(_ n:Int){lock.lock();frames += n;chunks += 1;lock.unlock()}
    func result()->(Int,Int){lock.lock();defer{lock.unlock()};return(frames,chunks)}
}
func align(_ reference:[Double],_ candidate:[Double])->[String:Any] {
    var offsets:[Double]=[], correlations:[Double]=[]
    for center in [20,100,180] {
        let first=max(100,(center-10)*100), last=min(reference.count-100,(center+10)*100)
        var best = -Double.infinity, selected=0
        for lag in -300...300 {
            var x=0.0,y=0.0,xx=0.0,yy=0.0,xy=0.0,n=0.0
            for i in first..<last where i+lag>=0 && i+lag<candidate.count {
                let a=reference[i],b=candidate[i+lag];x += a;y += b;xx += a*a;yy += b*b;xy += a*b;n += 1
            }
            let v=(xy-x*y/n)/max(1e-20,sqrt(max(0,xx-x*x/n)*max(0,yy-y*y/n)))
            if v>best {best=v;selected=lag}
        }
        offsets.append(Double(selected)*0.01);correlations.append(best)
    }
    let sorted=offsets.sorted(), lag=sorted[1]
    return ["offsetSeconds":lag,"windowOffsets":offsets,"windowCorrelations":correlations,"driftRangeSeconds":(offsets.max() ?? 0)-(offsets.min() ?? 0),"resolutionSeconds":0.01]
}
