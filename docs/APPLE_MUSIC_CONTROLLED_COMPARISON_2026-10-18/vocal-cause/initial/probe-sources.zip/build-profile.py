import gzip, json, math, hashlib
from pathlib import Path
import numpy as np

root = Path('/private/tmp/music-prayer-vocal-cause')
source = Path('docs/APPLE_MUSIC_CONTROLLED_COMPARISON_2026-10-18/pitch-cause/spectral-diagnostics.json.gz')
with gzip.open(source) as file:
    data = json.load(file)
normal = np.asarray(data['normalSpectrum'], dtype=np.float64)
off = np.asarray(data['offSpectrum'], dtype=np.float64)
assert normal.shape == off.shape and normal.shape[1] == 168
frequency = 80 * 2 ** (np.arange(168) / 24)
difference_db = (off - normal) * (10 / np.log(10))
mean_db = np.mean(difference_db, axis=0)
median_db = np.median(difference_db, axis=0)
profile = {
    'source': str(source), 'sourceSHA256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'frameCount': len(normal), 'binCount': 168, 'sampleRate': data['normalRate'],
    'sourceLogarithm': 'natural logarithm of power',
    'differenceDefinition': 'offSpectrum - normalSpectrum; converted to dB with 10 / ln(10)',
    'powerRatioDefinition': 'exp(mean(offLogPower - normalLogPower))',
    'amplitudeRatioDefinition': 'sqrt(powerRatio) = 10 ** (meanDifferenceDB / 20)',
    'bins': [{'index': int(i), 'frequencyHz': float(frequency[i]),
              'meanDifferenceDB': float(mean_db[i]), 'medianDifferenceDB': float(median_db[i]),
              'meanAbsoluteDifferenceDB': float(np.mean(np.abs(difference_db[:, i]))),
              'amplitudeRatio': float(10 ** (mean_db[i] / 20))}
             for i in range(168)]
}
(root / 'high-frequency-profile.json').write_text(json.dumps(profile, ensure_ascii=False, indent=2) + '\n')

# Use only negative systematic attenuation above 6 kHz. Keep lower bands exactly unity.
mask = frequency > 6000
high_f = frequency[mask]
high_db = np.minimum(mean_db[mask], 0)
# Three-point triangular smoothing. Linear extrapolation prevents endpoint flattening.
padded = np.r_[2 * high_db[0] - high_db[1], high_db, 2 * high_db[-1] - high_db[-2]]
smoothed = .25 * padded[:-2] + .5 * padded[1:-1] + .25 * padded[2:]
smoothed = np.minimum.accumulate(np.minimum(smoothed, 0))
sample_rate = 24000
nyquist = sample_rate / 2
last_slope = (smoothed[-1] - smoothed[-2]) / (high_f[-1] - high_f[-2])
nyquist_db = max(-120.0, float(smoothed[-1] + last_slope * (nyquist - high_f[-1])))
fit_f = np.r_[0, 6000, high_f, nyquist]
fit_db = np.r_[0, 0, smoothed, nyquist_db]
fft_n = 32768
fft_f = np.fft.rfftfreq(fft_n, 1 / sample_rate)
target_db = np.interp(fft_f, fit_f, fit_db)
target_amplitude = 10 ** (target_db / 20)
impulse = np.fft.fftshift(np.fft.irfft(target_amplitude, n=fft_n))
length = 1025
center = length // 2
coefficients = impulse[fft_n // 2 - center:fft_n // 2 + center + 1] * np.kaiser(length, 8)
coefficients /= coefficients.sum()
# Symmetric kernel with centered convolution has zero group delay on the original timeline.
assert np.max(np.abs(coefficients - coefficients[::-1])) < 1e-15
omega = 2 * np.pi * frequency / sample_rate
actual = np.cos(np.outer(omega, np.arange(length) - center)) @ coefficients
actual_db = 20 * np.log10(np.maximum(np.abs(actual), 1e-15))
fit_at_bins = np.interp(frequency, fit_f, fit_db)
pass_f = np.arange(0, 6001, 10)
pass_actual = np.cos(np.outer(2 * np.pi * pass_f / sample_rate, np.arange(length) - center)) @ coefficients
result = {
    'sampleRate': sample_rate, 'length': length, 'centerIndex': center,
    'coefficients': coefficients.tolist(),
    'application': 'For each channel, y[n] = sum(coefficients[k] * x[n + centerIndex - k]). Use reflection padding at boundaries; retain original frame count. This is one centered convolution, not forward-backward filtfilt.',
    'phase': 'real symmetric finite impulse response; center aligned offline application has zero time shift',
    'fit': {'unityPassbandThroughHz': 6000, 'smoothing': '3-point triangular weights [.25,.5,.25] on negative mean dB differences; monotone nonincreasing above 6 kHz',
            'amplitudeFromPower': 'sqrt(exp(mean(offLogPower-normalLogPower)))',
            'interpolation': 'linear in dB vs frequency; inverse real FFT then 1025-sample Kaiser beta=8 truncation; DC normalized to unity',
            'lastMeasuredFrequencyHz': float(frequency[-1]),
            'unmeasuredHighFrequencyTreatment': 'Above last measured bin, continue last smoothed dB slope to Nyquist with floor -120 dB. This continuation is an assumption, not a measurement.',
            'nyquistTargetDB': nyquist_db,
            'maximumPassbandMagnitudeDeviationDB': float(np.max(np.abs(20 * np.log10(np.abs(pass_actual))))),
            'maximumMeasuredBinFitErrorDB': float(np.max(np.abs(actual_db - fit_at_bins)))},
    'responseAtMeasuredBins': [{'frequencyHz': float(frequency[i]), 'targetDB': float(fit_at_bins[i]), 'actualDB': float(actual_db[i])} for i in range(168)],
    'limitations': ['The archived spectrum uses mono (L+R)/2, 4096-sample Hann windows, narrow log-frequency bands, and 0.2-second steps.',
                    'The fit models systematic magnitude attenuation only; it does not claim to restore phase, stereo coherence, or missing information.',
                    'A matching vocal-activity change would support high-frequency attenuation as a causal contributor for this excerpt; absence of a change would reject this modeled attenuation as a sufficient explanation.']
}
(root / 'fir-coefficients.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'profile': str(root/'high-frequency-profile.json'), 'filter': str(root/'fir-coefficients.json'), 'shape': list(normal.shape), 'fit': result['fit']}))
