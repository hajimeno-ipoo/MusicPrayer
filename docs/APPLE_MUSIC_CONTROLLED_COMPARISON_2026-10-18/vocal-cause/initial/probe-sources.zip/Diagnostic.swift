import AVFoundation
import Accelerate
import Foundation
extension PCMClip {
    func mono(_ channel:Int = -1, invert:Bool = false)->PCMClip {
        let b=Self.allocate(rate,1,frames),p=b.floatChannelData![0],n=Int(buffer.format.channelCount)
        for i in 0..<frames {var v:Float=0;if channel>=0{v=buffer.floatChannelData![channel][i]}else{for c in 0..<n{v += buffer.floatChannelData![c][i]/Float(n)}};p[i]=invert ? -v:v}
        return PCMClip(buffer:b)
    }
    func stats()->[String:Any] {
        let n=Double(frames);var values:[[String:Double]]=[]
        for c in 0..<Int(buffer.format.channelCount){let p=buffer.floatChannelData![c];var sum=0.0,sq=0.0,peak=0.0,clip=0.0
            for i in 0..<frames {let v=Double(p[i]);sum += v;sq += v*v;peak=max(peak,abs(v));if abs(v)>=1{clip += 1}}
            values.append(["rms":sqrt(sq/n),"dc":sum/n,"peak":peak,"clippedFraction":clip/n])
        }
        var cross=0.0,aa=0.0,bb=0.0,mid=0.0,side=0.0
        if buffer.format.channelCount==2{let a=buffer.floatChannelData![0],b=buffer.floatChannelData![1];for i in 0..<frames{let x=Double(a[i]),y=Double(b[i]);cross += x*y;aa += x*x;bb += y*y;mid += pow((x+y)/2,2);side += pow((x-y)/2,2)}}
        return ["channels":values,"leftRightCorrelation":cross/max(1e-30,sqrt(aa*bb)),"midRMS":sqrt(mid/n),"sideRMS":sqrt(side/n)]
    }
}
func waveformCompare(_ a:PCMClip,_ b:PCMClip)->[[String:Double]] {
    precondition(a.rate==b.rate)
    let x=a.mono().buffer,y=b.mono().buffer,px=x.floatChannelData![0],py=y.floatChannelData![0],rate=a.rate
    var results:[[String:Double]]=[]
    for center in [10.0,20.0,30.0] {
        let first=Int((center-0.25)*rate),last=Int((center+0.25)*rate),margin=Int(rate*0.025)
        var best = -1.0,selected=0,bestXY=0.0,bestXX=0.0,bestYY=0.0
        for lag in -margin...margin {var xx=0.0,yy=0.0,xy=0.0
            for i in first..<last {let v=Double(px[i]),w=Double(py[i+lag]);xx += v*v;yy += w*w;xy += v*w}
            let c=xy/max(1e-30,sqrt(xx*yy));if abs(c)>abs(best) || best == -1 {best=c;selected=lag;bestXY=xy;bestXX=xx;bestYY=yy}
        }
        results.append(["center":center,"offsetSamples":Double(selected),"offsetSeconds":Double(selected)/rate,"correlation":best,"gainBoverA":bestXY/max(1e-30,bestXX),"normalizedResidual":sqrt(max(0,1-pow(best,2))),"rmsRatio":sqrt(bestYY/max(1e-30,bestXX))])
    }
    return results
}

extension PCMClip {
    func filtered(_ coefficients:[Float])->PCMClip {
        precondition(rate==24000 && coefficients.count%2==1)
        let center=coefficients.count/2,b=Self.allocate(rate,buffer.format.channelCount,frames)
        for c in 0..<Int(buffer.format.channelCount) {
            var padded=[Float](repeating:0,count:frames+2*center)
            padded.withUnsafeMutableBufferPointer{ p in memcpy(p.baseAddress!+center,buffer.floatChannelData![c],frames*4) }
            padded.withUnsafeBufferPointer{ p in coefficients.withUnsafeBufferPointer{ h in
                vDSP_conv(p.baseAddress!,1,h.baseAddress!,1,b.floatChannelData![c],1,vDSP_Length(frames),vDSP_Length(coefficients.count))
            }}
        }
        return PCMClip(buffer:b)
    }
}
