import AppKit
import AVFoundation
import CoreAudio
import Foundation
import MusicUnderstanding
import WebKit
extension Bundle {static var module:Bundle{.main}}
@main struct Probe {
    static func main(){let app=NSApplication.shared,d=Delegate();app.delegate=d;app.setActivationPolicy(.regular);app.run();_ = d}
}
@MainActor final class Delegate:NSObject,NSApplicationDelegate {
    let root=URL(fileURLWithPath:"/private/tmp/music-prayer-vocal-cause")
    let capture=ProbeCapture()
    var view:WKWebView!,window:NSWindow!,webWindow:NSWindow!
    let label=NSTextField(wrappingLabelWithString:"macOSの音声取得許可を確認します。確認画面が出たら許可してください。")
    func applicationDidFinishLaunching(_ n:Notification){Task{await run()}}
    func log(_ event:String,_ extra:[String:Any]=[:]){
        var v=extra;v["event"]=event;v["date"]=ISO8601DateFormatter().string(from:Date())
        let url=root.appendingPathComponent("events.jsonl")
        guard let data=try? JSONSerialization.data(withJSONObject:v,options:[.sortedKeys]) else{return}
        if !FileManager.default.fileExists(atPath:url.path){FileManager.default.createFile(atPath:url.path,contents:nil)}
        if let h=try? FileHandle(forWritingTo:url){_ = try? h.seekToEnd();try? h.write(contentsOf:data);try? h.write(contentsOf:Data([10]));try? h.close()}
    }
    func raw(_ script:String) async throws -> Any? {try await view.callAsyncJavaScript(script,arguments:[:],in:nil,contentWorld:.page)}
    func call(_ command:String,_ value:Any=0) async throws -> AppleMusicPlayback {
        try AppleMusicBridge.decode(await view.callAsyncJavaScript(AppleMusicBridge.invocation,arguments:["command":command,"value":value],in:nil,contentWorld:.page))
    }
    func info() async -> [String:Any]{
        (try? await raw("""
        const m=document.getElementById('apple-music-player'),k=window.MusicKit?.getInstance();
        return {time:Number(m?.currentTime)||0,rate:Number(m?.playbackRate)||0,preservesPitch:m?.preservesPitch??null,paused:m?.paused??true,
        playing:!!k?.isPlaying,volume:k?.volume??-1,id:String(k?.nowPlayingItem?.id||''),protected:!!m?.webkitKeys};
        """) as? [String:Any]) ?? [:]
    }
    func configure(_ speed:Double,_ pitch:Bool) async throws {
        _ = try await view.callAsyncJavaScript("""
        const m=document.getElementById('apple-music-player'),k=window.MusicKit.getInstance();
        if('playbackRate' in k) Reflect.set(k,'playbackRate',rate);
        m.playbackRate=rate;m.preservesPitch=pitch;return {rate:m.playbackRate,preservesPitch:m.preservesPitch};
        """,arguments:["rate":speed,"pitch":pitch],in:nil,contentWorld:.page)
    }
    func record(_ name:String,_ speed:Double,_ pitch:Bool) async throws -> PCMClip {
        _ = try await call("prepareSong","1403236244")
        // Queue preparation can replace the media element at the first play. Warm that element before configuring it.
        _ = try await call("volume",0);_ = try await call("toggle");try await configure(speed,pitch)
        _ = try await call("pause");_ = try await call("seek",30);try await configure(speed,pitch)
        _ = try await call("volume",0.12)
        capture.collector.begin();let began=Date();_ = try await call("toggle");try await configure(speed,pitch)
        let actual=await info()
        log("captureStart",["name":name,"info":actual,"mute":try capture.muteReadback()])
        guard actual["rate"] as? Double == speed, actual["preservesPitch"] as? Bool == pitch else {throw NSError(domain:"Probe.playbackConditionMismatch",code:1)}
        var state=AppleMusicPlayback(),next=0
        while Date().timeIntervalSince(began)<240 {
            state=try await call("snapshot",0.12)
            if state.time>=70 || state.ended{_ = try await call("pause");break}
            if state.isPlaying {
                let actual=await info()
                guard actual["rate"] as? Double == speed,actual["preservesPitch"] as? Bool == pitch else {throw NSError(domain:"Probe.playbackConditionChanged",code:1)}
            }
            let tick=Int(Date().timeIntervalSince(began)/30)
            if tick>=next{next=tick+1;label.stringValue="無音で音声を取得中: \(name)\n\(Int(state.time)) / 約209秒";log("captureProgress",["name":name,"wall":Date().timeIntervalSince(began),"media":state.time,"rms":capture.features().rms])}
            try await Task.sleep(for:.milliseconds(20))
        }
        let (clip,stats)=try capture.collector.end()
        guard state.time>=69.9 else{throw NSError(domain:"Probe.captureTimeout",code:1)}
        log("captureResult",["name":name,"wall":Date().timeIntervalSince(began),"frames":clip.frames,"rate":clip.rate,"channels":clip.buffer.format.channelCount,"duration":clip.duration,"stats":stats,"mute":try capture.muteReadback(),"info":await info()])
        return clip
    }
    func analyze(_ clip:PCMClip,_ name:String,_ scale:Double=1) async throws {
        label.stringValue="取得した音声を比較解析中: \(name)"
        let chunks=clip.chunks(),counter=FeedCounter(),provider=PCMSequence(values:chunks,counter:counter)
        let session=MusicUnderstandingSession(audioProvider:provider),began=Date()
        log("analysisStart",["name":name,"frames":clip.frames,"rate":clip.rate,"duration":clip.duration,"chunks":chunks.count,"sha256":clip.fingerprint(),"timeScale":scale])
        let result=try await session.analyze(for:[.key,.rhythm,.structure,.pace,.instrumentActivity,.loudness])
        var v=MusicAnalyzer.convert(result,duration:clip.duration,fingerprint:name)
        if scale != 1 {
            func span(_ a:TimeSpan)->TimeSpan{TimeSpan(start:a.start*scale,duration:a.duration*scale)}
            func values(_ a:[TimeValue])->[TimeValue]{a.map{TimeValue(time:$0.time*scale,value:$0.value)}}
            v.duration *= scale;v.beats=v.beats.map{$0*scale};v.bars=v.bars.map{$0*scale};v.bpm=v.bpm.map{$0/Float(scale)}
            v.sections=v.sections.map(span);v.segments=v.segments.map(span);v.phrases=v.phrases.map(span)
            v.pace=v.pace.map{PaceSpan(range:span($0.range),value:$0.value)}
            v.keys=v.keys.map{KeySpan(range:span($0.range),label:$0.label,hue:$0.hue,minor:$0.minor)}
            v.vocal=values(v.vocal);v.drums=values(v.drums);v.bass=values(v.bass);v.other=values(v.other)
            v.momentary=values(v.momentary);v.shortTerm=values(v.shortTerm)
            if let p=v.peak{v.peak=TimeValue(time:p.time*scale,value:p.value)}
            v.instrumentRanges.vocal=v.instrumentRanges.vocal.map(span);v.instrumentRanges.drums=v.instrumentRanges.drums.map(span)
            v.instrumentRanges.bass=v.instrumentRanges.bass.map(span);v.instrumentRanges.other=v.instrumentRanges.other.map(span)
        }
        let consumed=counter.result()
        guard consumed.0==clip.frames,consumed.1==chunks.count else{throw NSError(domain:"Probe.feedCountMismatch",code:consumed.0)}
        let encoder=JSONEncoder();encoder.outputFormatting=[.sortedKeys]
        try encoder.encode(v).write(to:root.appendingPathComponent(name+".json"))
        log("analysisResult",["name":name,"seconds":Date().timeIntervalSince(began),"fedFrames":consumed.0,"fedChunks":consumed.1,"duration":v.duration,"bpm":v.bpm ?? 0,"beats":v.beats.count,"bars":v.bars.count,"pace":v.pace.count,"sections":v.sections.count,"keys":v.keys.map(\.label)])
    }
    func run() async {
        log("start",["pid":ProcessInfo.processInfo.processIdentifier])
        window=NSWindow(contentRect:NSRect(x:0,y:0,width:490,height:150),styleMask:[.titled],backing:.buffered,defer:false)
        window.title="MusicPrayer 歌声判定の原因確認";label.frame=NSRect(x:20,y:20,width:450,height:100);window.contentView?.addSubview(label)
        window.center();window.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true)
        do {
            let baseline=Set(try AudioProcess.all().map(\.pid)),configuration=WKWebViewConfiguration()
            configuration.websiteDataStore = .default();configuration.mediaTypesRequiringUserActionForPlayback=[]
            view=WKWebView(frame:NSRect(x:0,y:0,width:800,height:600),configuration:configuration)
            webWindow=NSWindow(contentRect:view.frame,styleMask:[.titled],backing:.buffered,defer:false);webWindow.contentView=view;webWindow.orderBack(nil)
            view.load(URLRequest(url:URL(string:"https://music.apple.com/jp/browse")!))
            var ready=false
            for _ in 0..<180 {
                if let s=try? await call("snapshot",0),s.isReady {guard s.isAuthorized else{throw NSError(domain:"Probe.MusicKitLogin",code:1)};ready=true;log("musicKitReady");break}
                try await Task.sleep(for:.milliseconds(500))
            }
            guard ready else{throw NSError(domain:"Probe.webReadyTimeout",code:1)}
            _ = try await call("volume",0);_ = try await call("playSong","1403236244")
            let candidates=try AudioProcess.all().filter{$0.bundleID=="com.apple.WebKit.GPU" && !baseline.contains($0.pid)}
            guard candidates.count==1 else{throw NSError(domain:"Probe.ambiguousProcess",code:candidates.count)}
            _ = try await call("pause");capture.setPlaybackVolume(0.12);try await capture.startProbe(process:candidates[0].id)
            _ = try await call("volume",0.12);try await configure(1,true);_ = try await call("toggle")
            var nonzero=0
            for _ in 0..<50{if capture.features().rms>0.00001{nonzero += 1};try await Task.sleep(for:.milliseconds(100))}
            _ = try await call("pause")
            log("permissionPreflight",["nonzero":nonzero,"mute":try capture.muteReadback(),"processPID":candidates[0].pid])
            guard nonzero>0 else{throw NSError(domain:"Probe.noPCM",code:1)}
            label.stringValue="音声取得を確認しました。macOSの許可ログを照合しています。";log("waitingPermissionAudit")
            var permission=false
            for _ in 0..<300{if FileManager.default.fileExists(atPath:root.appendingPathComponent("permission-confirmed").path){permission=true;break};try await Task.sleep(for:.seconds(1))}
            guard permission else{throw NSError(domain:"Probe.permissionAuditTimeout",code:1)}
            log("permissionAuditConfirmed")
            let original=try await record("native_1x",1,true)
            let shifted=try await record("pitch_shifted_2x",2,false)
            _ = try await call("pause");try await configure(1,true)
            let shiftAlign=align(original.envelope(originalTimeScale:1),shifted.envelope(originalTimeScale:2))
            let offset=shiftAlign["offsetSeconds"] as! Double
            let start=max(0,-offset)+0.02,end=min(original.duration,shifted.duration*2-offset)-0.02,duration=end-start
            guard duration>35 else{throw NSError(domain:"Probe.commonRangeTooShort",code:1)}
            log("alignment",["pitchShifted":shiftAlign,"commonStart":start,"commonEnd":end,"commonDuration":duration])
            let reference=original.slice(start:start,duration:duration)
            let normal=try reference.resample(24000)
            let off=shifted.slice(start:(start+offset)/2,duration:duration/2).relabel(shifted.rate/2)
            log("waveform",["reference":normal.stats(),"off":off.stats(),"comparison":waveformCompare(normal,off)])
            let off48=try off.resample(48000)
            var variants:[String:PCMClip]=["reference48":reference,"reference24":normal,"off24":off,"off48":off48,
                "referenceMono":normal.mono(),"offMono":off.mono(),"referenceLeft":normal.mono(0),"offLeft":off.mono(0),
                "referenceRight":normal.mono(1),"offRight":off.mono(1),"referenceInverted":normal.mono(-1,invert:true),"offInverted":off.mono(-1,invert:true)]
            let filterData=try Data(contentsOf:root.appendingPathComponent("fir-coefficients.json"))
            let filterSpec=try JSONSerialization.jsonObject(with:filterData) as! [String:Any]
            let coefficients=(filterSpec["coefficients"] as! [Double]).map{Float($0)}
            variants["referenceFiltered"]=normal.filtered(coefficients)
            variants["offFiltered"]=off.filtered(coefficients)
            let spectra:[String:Any]=["normal":spectralFrames(normal),"off":spectralFrames(off),"filtered":spectralFrames(variants["referenceFiltered"]!),"sampleRate":24000,"frequencyHz":(0..<174).map{80*pow(2,Double($0)/24)},"edgePadding":"zero; exclude first and final 1 second from spectral metrics"]
            try JSONSerialization.data(withJSONObject:spectra).write(to:root.appendingPathComponent("spectra.json"))
            for name in ["off24","reference24","off24","reference48","off48","referenceFiltered","offFiltered"] {try await analyze(variants[name]!,name+"_"+UUID().uuidString.prefix(6))}
            log("readyForDiagnostics")
            label.stringValue="基本比較が終了しました。音声をメモリに保持して原因を確認しています。"
            var last=Date()
            while Date().timeIntervalSince(last)<600 {
                let command=root.appendingPathComponent("command.json")
                if let d=try? Data(contentsOf:command), let cmd=try? JSONSerialization.jsonObject(with:d) as? [String:Any] {
                    try? FileManager.default.removeItem(at:command);last=Date()
                    if cmd["stop"] as? Bool == true {break}
                    for name in cmd["analyze"] as? [String] ?? [] {guard let clip=variants[name] else{continue};try await analyze(clip,name+"_"+UUID().uuidString.prefix(6))}
                    log("diagnosticsFinished")
                }
                try await Task.sleep(for:.milliseconds(300))
            }
            log("done")
        } catch{log("failure",["description":String(describing:error),"error":error.localizedDescription])}
        if view != nil{_ = try? await call("pause");try? await configure(1,true);log("restored",["info":await info()]);view.stopLoading()}
        capture.stop();webWindow?.orderOut(nil);window.orderOut(nil);NSApp.terminate(nil)
    }
}
