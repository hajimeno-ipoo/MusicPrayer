import json, hashlib
from pathlib import Path
import numpy as np
root=Path('/private/tmp/music-prayer-vocal-cause')
p=root/'spectra.json';d=json.loads(p.read_text())
a=np.array(d['normal'],dtype=np.float64);b=np.array(d['off'],dtype=np.float64)
f=np.array(d['frequencyHz'],dtype=np.float64);rate=float(d['sampleRate']);nyquist=rate/2
assert a.shape==b.shape and len(f)==a.shape[1] and len(f)==174
raw_db=np.mean(b-a,axis=0)*10/np.log(10)
mask=f>6000
# Keep each measured target exactly above 6 kHz. Do not smooth or enforce monotonicity.
freq=np.r_[0,6000,f[mask],nyquist]
end_db=float(raw_db[-1]+(raw_db[-1]-raw_db[-2])/(f[-1]-f[-2])*(nyquist-f[-1]))
dbs=np.r_[0,0,raw_db[mask],end_db]
fft_n=131072;length=4097;center=length//2
fft_freq=np.fft.rfftfreq(fft_n,1/rate)
target=10**(np.interp(fft_freq,freq,dbs)/20)
impulse=np.fft.fftshift(np.fft.irfft(target,n=fft_n))
h=impulse[fft_n//2-center:fft_n//2+center+1]*np.kaiser(length,16)
h/=h.sum()
actual=np.cos(np.outer(2*np.pi*f/rate,np.arange(length)-center))@h
actual_db=20*np.log10(np.maximum(np.abs(actual),1e-20))
fit_db=np.interp(f,freq,dbs)
pass_freq=np.arange(0,6000.1,5)
pass_actual=np.cos(np.outer(2*np.pi*pass_freq/rate,np.arange(length)-center))@h
error=np.abs(actual_db-fit_db)
result={'sampleRate':int(rate),'length':length,'centerIndex':center,'coefficients':h.tolist(),
'application':'One centered convolution per channel: y[n] = sum(coefficients[k] * x[n+centerIndex-k]); use original frame count. Zero padding is permitted; exclude 1 s at each edge in comparison. Not filtfilt.',
'source':str(p),'sourceSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),
'fit':{'sourceFrames':len(a),'sourceBins':len(f),'unityPassbandThroughHz':6000,'smoothing':'none; use measured mean dB difference directly above 6 kHz',
'differenceDefinition':'mean(offLogPower-normalLogPower)*10/ln(10)',
'amplitudeDefinition':'sqrt(exp(mean(offLogPower-normalLogPower))) = 10**(meanDifferenceDB/20)',
'interpolation':'linear in dB vs frequency; 131072-point inverse real FFT; 4097 symmetric taps; Kaiser beta 16; DC normalized',
'lastMeasuredFrequencyHz':float(f[-1]),'unmeasuredHighFrequencyTreatment':'Above final measured bin only, extrapolate the slope between the last two measured dB points to Nyquist. Not a measurement.',
'nyquistTargetDB':end_db,'maximumPassbandMagnitudeDeviationDB':float(np.max(np.abs(20*np.log10(np.abs(pass_actual))))),
'maximumMeasuredBinFitErrorDB':float(np.max(error)),
'maximumFitErrorDBWhereTargetAboveMinus60DB':float(np.max(error[fit_db>-60])),
'maximumSymmetryError':float(np.max(np.abs(h-h[::-1])))},
'responseAtMeasuredBins':[{'index':int(i),'frequencyHz':float(f[i]),'measuredDifferenceDB':float(raw_db[i]),'targetDB':float(fit_db[i]),'actualDB':float(actual_db[i]),'fitErrorDB':float(error[i])} for i in range(len(f))],
'limitations':['The near-Nyquist archived spectrum is affected by its Hann window, averaging bands, and energy floor; this kernel fits those reported magnitudes rather than claiming an exact physical transfer function.','A matched vocal change establishes only this magnitude attenuation as a sufficient contributor for the excerpt; it does not identify Apple internal implementation.']}
(root/'fir-refined.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result['fit']))
for i in range(160,174):print(i,round(f[i]),round(fit_db[i],3),round(actual_db[i],3),round(error[i],3))
