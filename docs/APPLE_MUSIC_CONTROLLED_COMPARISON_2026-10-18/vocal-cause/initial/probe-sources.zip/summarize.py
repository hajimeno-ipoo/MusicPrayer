import json,pathlib,statistics,math,bisect
r=pathlib.Path(__import__('sys').argv[1]);results={}
for p in sorted(r.glob('*.json')):
 try:
  v=json.loads(p.read_text())
  if isinstance(v,dict) and 'vocal' in v and 'fingerprint' in v:results[p.stem]=v
 except (KeyError,ValueError,TypeError):pass
ref=next(v for k,v in results.items() if k.startswith('reference24_'))
def value(a,t):
 i=bisect.bisect_right([x['time'] for x in a],t)-1
 return a[max(0,i)]['value']
grid=[i/20 for i in range(60,int((ref['duration']-3)*20))]
rvals=[value(ref['vocal'],t) for t in grid]
def corr(a,b):
 am=statistics.mean(a);bm=statistics.mean(b)
 return sum((x-am)*(y-bm) for x,y in zip(a,b))/max(1e-30,math.sqrt(sum((x-am)**2 for x in a)*sum((y-bm)**2 for y in b)))
metrics={}
for name,v in results.items():
 vals=[value(v['vocal'],t) for t in grid]
 metrics[name]={'duration':v['duration'],'fullMean':statistics.mean(x['value'] for x in v['vocal']),'interiorMean':statistics.mean(vals),'interiorBias':statistics.mean(x-y for x,y in zip(vals,rvals)),'interiorMAE':statistics.mean(abs(x-y) for x,y in zip(vals,rvals)),'interiorCorrelation':corr(vals,rvals),'pointCount':len(v['vocal'])}
out={'intervalSeconds':[3,grid[-1]],'gridStep':.05,'note':'Numerical activity units are framework scores, not measured vocal sound level or error percentage. Exclude first/final three seconds for padding/edge context.','metrics':metrics}
(r/'metrics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
