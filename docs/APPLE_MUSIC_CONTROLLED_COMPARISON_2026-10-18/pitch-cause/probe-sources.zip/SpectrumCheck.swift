import AVFoundation
import Foundation
enum AppleMusicAnalysisInput {static func copy(_ list:UnsafePointer<AudioBufferList>,sampleRate:Double,gain:Float)->AVAudioPCMBuffer?{nil}}
@main struct Check {
 static func main() throws {
  func clip(_ scale:Double)->PCMClip {
   let b=PCMClip.allocate(24000,1,120000)
   for i in 0..<120000 {
    let t=Double(i)/24000
    b.floatChannelData![0][i]=Float([173.0,391.0,1003.0].enumerated().reduce(0.0){$0 + sin(2*Double.pi*$1.element*scale*t)/Double($1.offset+1)})
   }
   return PCMClip(buffer:b)
  }
  let a=spectralFrames(clip(1)), same=score(a,a), down=score(a,spectralFrames(clip(0.5)))
  let s=(same["best"] as! [String:Any])["candidateSemitonesRelativeToReference"] as! Int
  let d=(down["best"] as! [String:Any])["candidateSemitonesRelativeToReference"] as! Int
  print("same=\(s), down=\(d)")
  guard s==0,d == -12 else{throw NSError(domain:"SpectrumCheck.failed",code:1)}
 }
}
