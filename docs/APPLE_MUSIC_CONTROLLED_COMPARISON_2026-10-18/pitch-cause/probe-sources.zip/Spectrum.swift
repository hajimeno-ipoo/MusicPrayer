import Accelerate
import AVFoundation
import Foundation

func spectralFrames(_ clip:PCMClip)->[[Double]] {
 let n=4096, half=n/2, bins=168,rate=clip.rate
 let setup=vDSP_create_fftsetup(vDSP_Length(12),FFTRadix(kFFTRadix2))!
 defer{vDSP_destroy_fftsetup(setup)}
 var window=[Float](repeating:0,count:n);vDSP_hann_window(&window,vDSP_Length(n),Int32(vDSP_HANN_NORM))
 var output:[[Double]]=[]
 let channels=Int(clip.buffer.format.channelCount),step=Int(rate*0.2)
 for first in stride(from:Int(rate*1),to:clip.frames-n-Int(rate),by:step) {
  var x=[Float](repeating:0,count:n),re=[Float](repeating:0,count:half),im=[Float](repeating:0,count:half),power=[Float](repeating:0,count:half)
  for c in 0..<channels {let p=clip.buffer.floatChannelData![c];for j in 0..<n{x[j] += p[first+j]/Float(channels)}}
  vDSP_vmul(x,1,window,1,&x,1,vDSP_Length(n))
  re.withUnsafeMutableBufferPointer{r in im.withUnsafeMutableBufferPointer{q in
   var split=DSPSplitComplex(realp:r.baseAddress!,imagp:q.baseAddress!)
   x.withUnsafeBufferPointer{v in v.baseAddress!.withMemoryRebound(to:DSPComplex.self,capacity:half){vDSP_ctoz($0,2,&split,1,vDSP_Length(half))}}
   vDSP_fft_zrip(setup,&split,1,vDSP_Length(12),FFTDirection(FFT_FORWARD))
   vDSP_zvmags(&split,1,&power,1,vDSP_Length(half))
  }}
  var row:[Double]=[]
  for b in 0..<bins {
   let f=80*pow(2,Double(b)/24),lo=max(1,Int(f*pow(2,-1/48.0)*Double(n)/rate)),hi=min(half-1,max(lo+1,Int(f*pow(2,1/48.0)*Double(n)/rate)))
   let value=(lo...hi).reduce(0.0){$0+Double(power[$1])}/Double(hi-lo+1)
   row.append(log(max(1e-16,value)))
  }
  output.append(row)
 }
 return output
}
func score(_ reference:[[Double]],_ candidate:[[Double]])->[String:Any] {
 var scores:[[String:Any]]=[]
 for semitones in -15...15 {
  let delta=semitones*2;var sx=0.0,sy=0.0,sxx=0.0,syy=0.0,sxy=0.0,n=0.0
  for t in 0..<min(reference.count,candidate.count) {
   let a=reference[t],b=candidate[t]
   // Equal time windows; compare central overlapping bands for each frequency shift.
   for i in 28..<120 where i+delta>=0 && i+delta<b.count {
    let x=a[i],y=b[i+delta];sx += x;sy += y;sxx += x*x;syy += y*y;sxy += x*y;n += 1
   }
  }
  let corr=(sxy-sx*sy/n)/max(1e-20,sqrt(max(0,sxx-sx*sx/n)*max(0,syy-sy*sy/n)))
  scores.append(["candidateSemitonesRelativeToReference":semitones,"correlation":corr])
 }
 let sorted=scores.sorted{($0["correlation"] as! Double)>($1["correlation"] as! Double)}
 return ["best":sorted.first!,"scores":scores,"framesCompared":min(reference.count,candidate.count)]
}
func diagnose(_ normal:PCMClip,_ kept:PCMClip,_ off:PCMClip,root:URL)throws {
 let a=spectralFrames(normal),b=spectralFrames(kept),c=spectralFrames(off)
 let result:[String:Any]=["normalRate":normal.rate,"duration":normal.duration,"pitchKeptAfterHalfRateInterpretation":score(a,b),"pitchOffAfterHalfRateInterpretation":score(a,c),"normalSpectrum":a,"keptSpectrum":b,"offSpectrum":c,"frequencyBins":"80*2^(bin/24) Hz; log power; native captured audio reinterpreted on original-time axis"]
 try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]).write(to:root.appendingPathComponent("diagnostics.json"))
 print("diagnostics complete")
}
