import AppKit
import SwiftUI
import Foundation
extension Bundle { static var module: Bundle { .main } }
@main struct Probe {
    static func main() { let app=NSApplication.shared; let delegate=Delegate(); app.delegate=delegate; app.setActivationPolicy(.regular); app.run(); _ = delegate }
}
@MainActor final class Delegate: NSObject, NSApplicationDelegate {
    let root=URL(fileURLWithPath:"/private/tmp/music-prayer-product-rate")
    var store: PlayerStore!
    var window: NSWindow!
    var webWindow: NSWindow!
    func log(_ event: String, _ data:[String:Any]=[:]) {
        var value=data;value["event"]=event;value["date"]=ISO8601DateFormatter().string(from:Date())
        guard let bytes=try? JSONSerialization.data(withJSONObject:value,options:[.sortedKeys]) else{return}
        let url=root.appendingPathComponent("events.jsonl")
        if !FileManager.default.fileExists(atPath:url.path){FileManager.default.createFile(atPath:url.path,contents:nil)}
        if let f=try? FileHandle(forWritingTo:url){_ = try? f.seekToEnd();try? f.write(contentsOf:bytes);try? f.write(contentsOf:Data([10]));try? f.close()}
    }
    func applicationDidFinishLaunching(_ n:Notification){ Task { await run() } }
    func run() async {
        log("start",["pid":ProcessInfo.processInfo.processIdentifier])
        store=PlayerStore(lyricDirectory:root.appendingPathComponent("lyrics"),appleMusicAnalysisDirectory:root.appendingPathComponent("analysis"))
        store.isAppleMusicSearchVisible=true
        let song=AppleMusicSong(id:"75073758",title:"DEPARTURES",artist:"globe",album:"",duration:323.109)
        store.tracks=[Track(appleMusicSong:song)];store.isAppleMusicActive=true
        let web=store.appleMusic.webViewForDisplay()
        webWindow=NSWindow(contentRect:NSRect(x:0,y:0,width:600,height:300),styleMask:[.titled],backing:.buffered,defer:false)
        webWindow.contentView=web;webWindow.orderBack(nil)
        window=NSWindow(contentRect:NSRect(x:0,y:0,width:1160,height:790),styleMask:[.titled,.closable],backing:.buffered,defer:false)
        window.title="MusicPrayer 製品処理の2倍速確認"
        window.contentView=NSHostingView(rootView:PlayerView(store:store));window.center();window.makeKeyAndOrderFront(nil)
        do {
            var ready=false
            for _ in 0..<240 {
                if store.appleMusic.playback.isReady && !store.appleMusic.isLoading {ready=true;break}
                try await Task.sleep(for:.milliseconds(500))
            }
            guard ready else {throw NSError(domain:"Probe.notReady",code:1)}
            log("pageReady", ["authorized":store.appleMusic.playback.isAuthorized])
            guard await store.appleMusic.playSong(song,autoplay:false) else {
                log("selectionFailure", ["searchError":store.appleMusic.searchError ?? "", "playback":String(describing:store.appleMusic.playback)])
                throw NSError(domain:"Probe.selection",code:1)
            }
            log("prepared",["authorized":store.appleMusic.playback.isAuthorized])
            store.isAppleMusicSearchVisible=false
            let began=Date();var started=false;var last = -1;var first: (date: Date, media: Double)?
            while Date().timeIntervalSince(began)<440 {
                try await Task.sleep(for:.seconds(1))
                let q=store.appleMusic.preanalysis
                let elapsed=Date().timeIntervalSince(began)
                if q.isWorking {started=true}
                if q.phase == .capturing && q.position > 0 {
                    if first == nil { first = (Date(), q.position) }
                    if let first, Date().timeIntervalSince(first.date) >= 30 {
                        let wall = Date().timeIntervalSince(first.date), media = q.position - first.media
                        log("actualRate", ["wallSeconds":wall,"mediaSeconds":media,"actualRate":media/wall])
                        break
                    }
                }
                let bucket=Int(elapsed/10)
                if bucket != last {
                    last=bucket
                    log("progress",["wall":elapsed,"media":q.position,"phase":String(describing:q.phase),"status":q.status(for:song),"isWorking":q.isWorking,"foregroundPlaying":store.isPlaying])
                }
                if started && !q.isWorking {
                    log("completed",["wall":elapsed,"status":q.status(for:song),"error":q.errors[song.id] ?? "","analysisLoaded":store.analysis != nil]);break
                }
            }
        } catch {log("failure",["error":String(describing:error)])}
        store.isAppleMusicSearchVisible=true
        await store.appleMusic.finishStorageBeforeTermination();store.shutdown()
        log("restored");window.orderOut(nil);NSApp.terminate(nil)
    }
}
